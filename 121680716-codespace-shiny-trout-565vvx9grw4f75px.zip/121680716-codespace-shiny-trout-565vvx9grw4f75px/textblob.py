import textblob
text = 'I love natural language processing! I am not like fish!'
blob = textblob.TextBlob(text)

for sentence in blob.sentences:
    print(sentence + '------>' +  str(sentence.sentiment.polarity))
