import sys

if len(sys.argv) != 2 or not sys.argv[1].endswith(".py"):
    sys.exit("Invalid arguments.")

try:
    with open(sys.argv[1]) as file:
        count = 0
        for line in file:
            if line.lstrip() and not line.lstrip().startswith('#'):
                count+= 1
        print(count)

except FileNotFoundError:
    sys.exit("File doesn't exist")
