def swap_left(lst, index):

    if index > 0:
        lst[index], lst[index - 1] = lst[index - 1], lst[index]


def swap_right(lst, index):

    if index < len(lst) - 1:
        lst[index], lst[index + 1] = lst[index + 1], lst[index]


def process_order(order):

    lst = list(order)

    b_index = lst.index('b')
    swap_left(lst, b_index)

    c_index = lst.index('c')
    swap_right(lst, c_index)

    a_index = lst.index('a')
    swap_left(lst, a_index)

    return lst


def main():

    permutations = [
        ('a', 'b', 'c'),
        ('a', 'c', 'b'),
        ('b', 'a', 'c'),
        ('b', 'c', 'a'),
        ('c', 'a', 'b'),
        ('c', 'b', 'a')
    ]

    # 验证每种排列是否最终结果都是 ['a', 'b', 'c']
    for perm in permutations:
        result = process_order(perm)
        print(f"初始顺序: {perm} -> 最终结果: {result}")

    print("所有情况均验证通过，最终结果最右边都是c！")


if __name__ == "__main__":
    main()
