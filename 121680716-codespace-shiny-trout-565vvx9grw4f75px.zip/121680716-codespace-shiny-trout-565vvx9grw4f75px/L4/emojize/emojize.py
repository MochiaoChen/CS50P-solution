import emoji

print("Output:", emoji.emojize(input("Input: "), language="alias"))
