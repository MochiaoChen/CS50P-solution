m = int(input("m: ").strip())
E = m*300000000*300000000
print("E:",int(E))
