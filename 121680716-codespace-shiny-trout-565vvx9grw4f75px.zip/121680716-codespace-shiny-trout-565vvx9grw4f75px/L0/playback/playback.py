print(input().replace(" ","..."))
