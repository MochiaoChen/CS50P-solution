name = input("What's your name? ")
name = name.s
print("hello", name)
